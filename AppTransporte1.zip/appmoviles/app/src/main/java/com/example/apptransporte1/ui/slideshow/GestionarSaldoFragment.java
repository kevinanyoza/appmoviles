package com.example.apptransporte1.ui.slideshow;

import android.app.Activity;

public class GestionarSaldoFragment extends fragment {

}
